require(['xapp/manager/Application'],function(Application){

    var appInstance = Application.getApp();

    console.log('got app instance : ',appInstance);
    

});
